package com.cg.frs.dao;

@SuppressWarnings("serial")
public class IDNotFoundException extends RuntimeException {
		public IDNotFoundException(String msg)
		{
			super(msg);
		}
		public IDNotFoundException(String msg,Throwable ex)
		{
			super(msg,ex);
		}

	}
