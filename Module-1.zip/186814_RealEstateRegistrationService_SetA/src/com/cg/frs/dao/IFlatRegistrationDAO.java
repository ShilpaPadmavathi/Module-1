package com.cg.frs.dao;

import com.cg.frs.dto.RegistrationDetails;

public interface IFlatRegistrationDAO {

	void registerFlat(RegistrationDetails rd);

	void showDetails(int ownerID);

}
