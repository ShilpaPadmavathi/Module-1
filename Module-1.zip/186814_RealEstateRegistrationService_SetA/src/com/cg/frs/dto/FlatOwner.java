package com.cg.frs.dto;

public class FlatOwner {
	private String name;
	private int ownerID;
	private String mblNo;//declaring variables
	
	//using getters setters methods
	public int getOwnerID() {
		return ownerID;
	}
	public void setOwnerID(int ownerID) {
		this.ownerID = ownerID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMblNo() {
		return mblNo;
	}
	public void setMblNo(String mblNo) {
		this.mblNo = mblNo;
	}
	//using constructor passing arguments
	public FlatOwner( int ownerID,String name, String mblNo) {
		super();
		this.ownerID = ownerID;
		this.name = name;
		this.mblNo = mblNo;
	}

	//default constructor
	public FlatOwner() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "FlatOwner [ownerID=" + ownerID + ", name=" + name + ", mblNo=" + mblNo + "]";
	}

	
}
