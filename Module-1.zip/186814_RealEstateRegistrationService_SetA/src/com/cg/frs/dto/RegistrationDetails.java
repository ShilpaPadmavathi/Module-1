package com.cg.frs.dto;

public class RegistrationDetails {
	private int ownerID;
	private int flatType;
	private double sq_ft;
	private long rentAmt;
	private long depositAmt;//declaring variables
	
	//using getters and setters methods
	public int getOwnerID() {
		return ownerID;
	}
	public void setOwnerID(int ownerID) {
		this.ownerID = ownerID;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public double getSq_ft() {
		return sq_ft;
	}
	public void setSq_ft(double sq_ft) {
		this.sq_ft = sq_ft;
	}
	public long getRentAmt() {
		return rentAmt;
	}
	public void setRentAmt(long rentAmt) {
		this.rentAmt = rentAmt;
	}
	public long getDepositAmt() {
		return depositAmt;
	}
	public void setDepositAmt(long depositAmt) {
		this.depositAmt = depositAmt;
	}
	
	//using constructors passing arguments
	public RegistrationDetails(int ownerID, int flatType, double sq_ft, long rentAmt, long depositAmt) {
		this.ownerID = ownerID;
		this.flatType = flatType;
		this.sq_ft = sq_ft;
		this.rentAmt = rentAmt;
		this.depositAmt = depositAmt;
	}
	//default constructor
	public RegistrationDetails() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "FlatRegistrationDTO [ownerID=" + ownerID + ", flatType=" + flatType + ", sq_ft=" + sq_ft + ", rentAmt="
				+ rentAmt + ", depositAmt=" + depositAmt + "]";
	}
	
	
	

}
