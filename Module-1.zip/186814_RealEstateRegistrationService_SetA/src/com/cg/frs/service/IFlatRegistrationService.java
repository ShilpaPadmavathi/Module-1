package com.cg.frs.service;

import com.cg.frs.dto.RegistrationDetails;

public interface IFlatRegistrationService {

	void registerFlat(RegistrationDetails rd);

	void showDetails(int ownerID);
	
	public int validationOwnerID(int ownerID);
	
	public int validationFlatType(int flatType);
	
	public double validationSquareFeet(double sq_ft);
	
	public long validationRentAmount(long rentAmt);
	
	public long validationDepositAmount(long depositAmt,long rentAmt);
	
}
