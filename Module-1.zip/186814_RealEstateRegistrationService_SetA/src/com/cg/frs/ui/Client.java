package com.cg.frs.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.frs.dao.IDNotFoundException;
import com.cg.frs.dto.RegistrationDetails;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Client {
	public static int getOption(Scanner sc)//checking whether it is integer or not
	{
		try
		{
			int option=sc.nextInt();
			return option;
		}
		catch(Throwable e)
		{
			System.out.println("String/Character values does not accept");
			return -1;
		}
	}
	public static void main(String[] args) {
		
		IFlatRegistrationService fs=new FlatRegistrationServiceImpl();// indirect calling service class for creating object name
		int option;
		int ownerID;// declaring variables
		int flatType = 0;
		double sq_ft = 0;
		long depositAmt = 0;
		long rentAmt = 0;
		
		Random r=new Random();// creating a random number using random method
		do// looping the statements which continues before the condition if false
		{
			System.out.println("1. Register Flat");
			System.out.println("2. Display Flat Registration Details");
			System.out.println("3.Exit");
			System.out.println("Enter your option: ");
			Scanner sc=new Scanner(System.in);// enter by user needs
			option = getOption(sc);// store the user input
			switch(option)
			{
			case 1:
				int a=r.nextInt(2000);
				System.out.println("Existing Owner IDs Are : [1,2,3]");
				
				System.out.println("Please enter your owner id from above list : ");
				ownerID=fs.validationOwnerID(sc.nextInt());
				System.out.println("Select Flat Type (1-BHK, 2-BHk): ");
				flatType=fs.validationFlatType(sc.nextInt());
				System.out.println("Enter Flat are in sq,ft : ");
				sq_ft=fs.validationSquareFeet(sc.nextDouble());
				System.out.println("Enter desired rent amount Rs : ");
				rentAmt=fs.validationRentAmount(sc.nextLong());
				System.out.println("Enter desired deposit amount : ");
				depositAmt=fs.validationDepositAmount(sc.nextLong(),rentAmt);
				RegistrationDetails rd=new RegistrationDetails(ownerID,flatType,sq_ft,rentAmt,depositAmt);// passing the bean class values to service class
				fs.registerFlat(rd);
				System.out.println("Flat successfully registered. Registration id: <"+a+">");
				break;
			case 2:
				try
				{
					System.out.println("Enter your owner id : ");
					ownerID=sc.nextInt();
					fs.showDetails(ownerID);//passing the value to service class
					System.out.println("Flat type : "+flatType);//display the details
					System.out.println("Square feet : "+sq_ft);
					System.out.println("Rent amount : "+rentAmt);
					System.out.println("Deposited amount : "+depositAmt);
				}
				catch(IDNotFoundException e)
				{
					System.out.println("owner does not exists");
				}
				break;
			case 3:
				System.out.println("Thanks for using us");
				System.exit(0);// exit the case
				break;
			default:
				System.out.println("Invalid option...");
				break;
			}
		}while(option!=3);// condition checking whether the given input is not equal to 3 or not
	}

}
