
public class Employee {
	public static int s(int a,int b) {
		return a+b;
	}
	public int sub() {
		int a=20;
		int b=10;
		return a-b;
	}
	void stmtPrnt() {
		System.out.println("This is Shilpa");
	}
	static void stmtPrnt1() {
		System.out.println("Prints Nothing");
	}
	public static void main(String[] args) {
		Employee e1=new Employee();
		e1.stmtPrnt();
		Employee.stmtPrnt1();
		System.out.println(Employee.s(5000, 2000));
		System.out.println(e1.sub());
	}

}
