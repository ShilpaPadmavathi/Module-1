package com.capgemini.contactbook.dao;
import java.util.HashMap;
import com.capgemini.contactbook.bean.EnquiryBean;

public interface ContactBookDaoImpl {
	public void addDetails(EnquiryBean bean);
	public void addEnquiry(EnquiryBean bean);
	public long getEnquiryDetails(long enqryId);
	
}