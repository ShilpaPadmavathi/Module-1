package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;

public interface ContactBookServiceImpl {
	public void addEnquiry(EnquiryBean bean);
	public long getEnquiryDetails(long enqryId);
	public String validationFirstName(String fName);
	public String validationLastName(String lName);
	public String validationPreferredLocation(String pLocation);
	public String validationPreferredDomain(String pDomain);
	public long validationContactNo(long contactNo);
}