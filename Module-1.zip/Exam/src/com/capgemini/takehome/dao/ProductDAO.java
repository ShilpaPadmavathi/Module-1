package com.capgemini.takehome.dao;
import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO {
	
CollectionUtil cu=new CollectionUtil();
	@Override
	public Product getProductDetails(int productCode) {
		Map m1=(Map) cu.getObject();
		Product pb2 = (Product) m1.get(productCode);
		return pb2;
	}

}
