package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements IProductService {
	static ProductDAO pd=new ProductDAO();

	@Override
	public Product getProductDetails(int productCode) throws Exception {
		int c=productCode;
		int count=0;
		while(c!=0) {
			c/=10;
			++count;
			if(count>4||count<4) {
				throw new Exception("Please Enter A Valid Code");
			}
		}
		Product pdao=pd.getProductDetails(productCode);
		return pdao;
		}
}
