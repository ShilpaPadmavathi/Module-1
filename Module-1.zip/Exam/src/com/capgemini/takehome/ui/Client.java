package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.service.ProductService;

public class Client {	
	static ProductService ps=new ProductService();
	static Product p;
	public static void main(String[] args) throws Exception {
		int d;
		Scanner sc=new Scanner(System.in);
		System.out.println("1)	Generate Bill by entering Product code and quantity ");
		System.out.println("2)	Exit");
		System.out.println("Enter Your Choice");
		d=sc.nextInt();
		switch(d) {
		case 1: System.out.println("Enter The Product Code");
		int code=sc.nextInt();
		System.out.println("Enter The Product Quantity");
		int quantity=sc.nextInt();
		if(quantity<=0) {
			System.out.println("Please Enter correct Quantity");
			System.exit(0);
		}
		Product pb=new Product(code,quantity);
		try {
				p = ps.getProductDetails(code);
				System.out.println("Product Name :"+p.getProductName()+'\n'+
						"Product Category :"+p.getProductCategory()+'\n'+"Product Price :"+p.getProductPrice()+
						'\n'+"Quantity: "+quantity+'\n'+"Line Total:"+quantity*p.getProductPrice());
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		break;
		case 2:System.exit(0);
		break;
		default:System.out.println("Sorry ! The Product Code is not available.");
		}
		
	}
	

}
