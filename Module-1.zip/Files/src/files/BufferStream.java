package files;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferStream {
	public static void main(String[] args) throws IOException {
		FileOutputStream outputStream=new FileOutputStream("Shilpa1.txt");
		BufferedOutputStream bos=new BufferedOutputStream(outputStream);
		String s="Shilpa";
		byte[] b=s.getBytes();
		bos.write(b);
		bos.flush();
		FileInputStream inputStream=new FileInputStream("Shilpa1.txt");
		BufferedInputStream inputStream1=new BufferedInputStream(inputStream);
		int i;
		while((i=inputStream.read())!=-1) {
			System.out.println((char)i);
		}
	}

}
