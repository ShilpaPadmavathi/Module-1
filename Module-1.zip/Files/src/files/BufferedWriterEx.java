package files;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterEx {
public static void main(String[] args) throws IOException {	
		FileWriter fw=new FileWriter("Shilpa.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		bw.write(97);
		bw.write("Shilpa");
		bw.newLine();
		char ch[]= {'a','b','c'};
		bw.write(ch);
		bw.flush();
		bw.close();
	}
}
