package files;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BytesEx {
public static void main(String[] args) throws IOException {
	FileOutputStream outputStream=new FileOutputStream("Shilpa1.txt");
	for(char i='a';i<='z';i++) {
		outputStream.write(i);
	}
	FileInputStream inputStream=new FileInputStream("Shilpa1.txt");
	int i;
	//while((i=inputStream.read())!=-1) {
	for(char i1='a';i1<='z';i1++) {
		System.out.println(i1);
	}
}
}
