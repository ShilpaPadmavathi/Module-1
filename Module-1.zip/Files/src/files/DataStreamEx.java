package files;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataStreamEx {
public static void main(String[] args) throws IOException {
	FileOutputStream fs=new FileOutputStream("Shilpa1.txt");
	DataOutputStream dos=new DataOutputStream(fs);
	dos.writeInt(1221);
	dos.writeUTF("GORANTLA PADMAVATHI SHILPA");
	DataInputStream dis=new DataInputStream(new FileInputStream("Shilpa1.txt"));
	System.out.println(dis.readInt());
	System.out.println(dis.readUTF());
	dos.close();
	dis.close();
}
}
