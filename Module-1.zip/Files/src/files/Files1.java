package files;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Files1 {
	
	public static void main(String[] args) throws IOException {
		
		File f=new File("Shilpa.txt");
		f.createNewFile();
		System.out.println("HAI TO FILES");
		f.mkdir();
		System.out.println(f.exists());
		System.out.println("HAI TO FOLDERS");
		FileWriter fw=new FileWriter("Shilpa.txt");
		fw.write(97);
		fw.write("Shilpa");
		fw.write("\n");
		char ch[]= {'a','b','c'};
		fw.flush();
		fw.close();
	}

}
