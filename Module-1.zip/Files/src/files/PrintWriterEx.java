package files;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterEx {
	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("Shilpa1.txt");
		PrintWriter pw=new PrintWriter(fw);
		pw.println(97);
		pw.println("Shilpa");
		char ch[]= {'a','b','c'};
		pw.write(ch);
		pw.flush();
		pw.close();
	}

}
