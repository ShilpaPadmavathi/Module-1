package files;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable{
	private int rollno;
	private String name;
	public int getrollno() {
		return rollno;
	}
	public void setrollno(int sno) {
		this.rollno = sno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
public class Serialization{
	public static void main(String[] args) throws IOException {
	Student student=new Student();
	student.setrollno(1221);
	student.setName("SHILPA");
	FileOutputStream fos=new FileOutputStream("Shilpa3.txt");
	ObjectOutputStream oos=new ObjectOutputStream(fos);
	oos.writeObject(student);
	System.out.println("SUCCESS");
	}

}
