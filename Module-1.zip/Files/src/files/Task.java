package files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Task {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Uname"); 
		String uname=sc.nextLine();
		System.out.println("Enter pwd");
		String pwd=sc.nextLine();
		File f=new File("Shilpa.txt");
		PrintWriter pw=new PrintWriter(f);
		pw.println(uname);
		pw.println(pwd);
		pw.flush();
		FileReader fr=new FileReader("Shilpa.txt");
		BufferedReader br=new BufferedReader(fr);
		String line=br.readLine();
		//System.out.println(line);
		while(line!=null) {
			//while(uname.equals(uname) && pwd.equals(pwd)) {
			System.out.println("Login Successfull");
			break;
			//}
			//break;
		}}
	}

