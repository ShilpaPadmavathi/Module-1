
class A{
	void m1()
	{
		System.out.println("Shilpa");
	}
	
}
class B extends A{
	void m2() {
		System.out.println("Padmavathi");
	}
}
class C extends A{
	void m3() {
		System.out.println("Gorantla");
	}
}
public class Single_Level{
	public static void main(String args[]) {
		
		C c1=new C();
		c1.m1();
		
		c1.m3();
	}
}
