interface A{
	void m1();
}
abstract class B{
	void m2()
	{
		System.out.println("Gorantla");
	}
	abstract void m3();
}
public class Interface extends B implements A{
	public static void main(String args[]) {
		
		Interface i=new Interface();
		i.m2();
		i.m1();
		i.m3();
	}

	@Override
	public void m1() {
		
		System.out.println("Padmavathi");
	}

	@Override
	void m3() {
		System.out.println("Shilpa");
		
	}

}
