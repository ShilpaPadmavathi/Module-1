package jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Java_Jdbc {
public static void main(String[] args) throws ClassNotFoundException, SQLException  {
	//loading the driver class
	Class.forName("oracle.jdbc.driver.OracleDriver");
	//Create Connection 
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shilpa","shilpa123");
	//create Statement
	Statement stmt=conn.createStatement();
	//Execute Query
	//boolean b=stmt.execute("create table shilpa12(id number(10),name varchar2(10))");
	//int b1=stmt.executeUpdate("insert into shilpa12 values(1221,'Shilpa')");
	//int b2=stmt.executeUpdate("insert into shilpa12 values(1203,'Pappu')");
	//int b3=stmt.executeUpdate("insert into shilpa12 values(1238,'Soumya')");
	//int b4=stmt.executeUpdate("insert into shilpa12 values(1204,'Bhanu')");
	ResultSet r=stmt.executeQuery("select * from shilpa12");
	while(r.next()) {
		System.out.println(r.getInt(1)+" "+r.getString(2));
	}
	//Close Connection
	conn.close();
	//System.out.println("Table Created"+b);
	//System.out.println("Values inserted"+b1+b2+b3+b4);
	//System.out.println("Displayed Data"+r);
}
}
