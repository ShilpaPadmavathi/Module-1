package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Task3 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Username");
		String uname=sc.next();
		System.out.println("Enter Password");
		String pass=sc.next();
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shilpa","shilpa123");
		PreparedStatement ps=conn.prepareStatement("select * from gmail where uname=? and password=?");
		ps.setString(1, uname);
		ps.setString(2, pass);
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			System.out.println("Login Successful");
		}
		else {
			System.out.println("Enter Username");
			String u=sc.next();
			System.out.println("Enter Password");
			String u1=sc.next();
			System.out.println("Enter Phone Number");
			String phone=sc.next();
			PreparedStatement ps1=conn.prepareStatement("insert into gmail values(?,?,?)");
			ps1.setString(1, u);
			ps1.setString(2, u1);
			ps1.setString(3, phone);
			int rs1=ps1.executeUpdate();
			if(rs1>0)
			System.out.println("Insertion Successful");
			else
				System.out.println("Unsuccessful");
		}
		sc.close();
		conn.close();
		
	}
	

}
