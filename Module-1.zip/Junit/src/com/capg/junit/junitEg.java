package com.capg.junit;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
public class junitEg {
	Add t=new Add();
	int i=t.sum(40, 100);
	int j=140;
	@Test
	public void testSum() {
		String a=null;
		String s="Shilpa";
		String s1="is";
		String s2="a";
		String s3="good";
		String s4="good";
		int var1=1;
		int var2=1;
		int[] arithmetic1= {1,2,3};
		int[] arithmetic2= {1,2,3};
		assertEquals(var1, var2);
		assertSame(s3,s4);
		assertNotSame(s, s1);
		assertNotNull(s1);
		assertNull(a);
		assertTrue(s3.equals(s4));
		assertFalse(s1.equals(s3));
		assertArrayEquals(arithmetic1, arithmetic2);
	}
	
	
	@Test
	public void m1() {
		System.out.println("This is Test Case 1");
	}
	@Before
	public void m2() {
		System.out.println("This is executed Before Every Test Case");
	}
	@Test
	public void m3() {
		System.out.println("This is TestCase 2");
	}
	@BeforeClass
	public static void m4() {
		System.out.println("This is executed Before All Test Cases");
	}
	@After
	public void m5() {
		System.out.println("This is executed After Every Test Case");
	}
	@AfterClass
	public static void m6() {
		System.out.println("This is executed After All Test Cases");
	}
	@Ignore
	public void m7() {
		System.out.println("This is Ignored");
	}}
