class A{
	A(){
		System.out.println("This is a DEFAULT CONSTRUCTOR OF PARENT");
	}
	A(int a){
		System.out.println("This is a PARAMETERIZED CONSTRUCTOR OF PARENT"+a);
	}
	void m1() {
		System.out.println("This is a METHOD OF PARENT");
	}
}
public class Key_Words extends A {
	Key_Words(){
		super();
		this.m1();
		super.m1();
		System.out.println("This is a DEFAULT CONSTRUCTOR OF CHILD");
	}
	Key_Words(int a){
		System.out.println("This is a PARAMETERIZED CONSTRUCTOR OF CHILD"+a);
	}
	void m1() {
		System.out.println("This is a METHOD OF CHILD");
	}
	public static void main(String args[]) {
	
		Key_Words k=new Key_Words(12);
		k.m1();
	}
}

