package com.capg.mobilebeans;

public class MobileBeans {
	private String actType;
	private String name;
	private float balance;

	public MobileBeans(String actType, String name, float balance) {
		super();
		this.actType = actType;
		this.name = name;
		this.balance = balance;
	}

	public String getActType() {
		return actType;
	}

	public void setActType(String actType) {
		this.actType = actType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
@Override
public String toString() {
	// TODO Auto-generated method stub
	return " "+actType+ " "+name+  " "+balance;
}
}
