package com.capg.mobiledao;
import java.util.HashMap;
import com.capg.mobilebeans.MobileBeans;
import com.capg.mobileui.MobileUi;
public class MobileDao implements MobileDaoI{
	HashMap hx=null;
public MobileDao() {
	hx=new HashMap();
	MobileBeans t1=new MobileBeans("Post-paid", "Shilpa", 200);
	MobileBeans t2=new MobileBeans("Pre-paid", "Jyothi", 300);
	MobileBeans t3=new MobileBeans("Post-paid", "Mahitha", 350);
	MobileBeans t4=new MobileBeans("Pre-paid", "Akshitha", 500);
	hx.put("8317580045", t1);
	hx.put("9840291500",t2);
	hx.put("9789850682",t3);
	hx.put("8125199885",t4);}



	@Override
	public MobileBeans userAccount(String  mb) {
		
		
	MobileBeans	mb1	=(MobileBeans) hx.get(mb);
		
		
		
		
		return mb1;
	}
	
	

}
