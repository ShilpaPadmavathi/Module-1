package com.capg.mobiledao;

import com.capg.mobilebeans.MobileBeans;

public interface MobileDaoI {

	MobileBeans userAccount(String  m);

}
