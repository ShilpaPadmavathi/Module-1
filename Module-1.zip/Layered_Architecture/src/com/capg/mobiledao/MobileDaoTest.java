package com.capg.mobiledao;

import org.junit.Test;

import com.capg.mobilebeans.MobileBeans;

public class MobileDaoTest {
	MobileDao md=new MobileDao();
	@Test
	public void testRechargeAccount_1() {
		String mobileNo="8317580045";
		MobileBeans mbefore=md.userAccount(mobileNo);
		System.out.println("Account="+mbefore.getBalance());
	}

}
