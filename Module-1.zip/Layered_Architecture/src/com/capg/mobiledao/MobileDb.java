package com.capg.mobiledao;

public class MobileDb {

}
