package com.capg.mobileservice;

import com.capg.mobilebeans.MobileBeans;
import com.capg.mobiledao.MobileDao;

public class MobileService implements MobileServiceI{
	MobileDao dao=new MobileDao();
	public MobileBeans userAccount(String mobileNo) {
	
		MobileBeans bean= dao.userAccount(mobileNo);
		
		return bean;
		
		
	}

}
