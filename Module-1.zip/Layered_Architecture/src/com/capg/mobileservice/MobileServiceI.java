package com.capg.mobileservice;

import com.capg.mobilebeans.MobileBeans;

public interface MobileServiceI {
	
	public MobileBeans userAccount(String mobileNo) ;	

}
