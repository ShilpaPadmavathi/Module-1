package com.capg.mobileui;

import java.util.Scanner;

import com.capg.mobilebeans.MobileBeans;
import com.capg.mobileservice.MobileService;

public class MobileUi {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Your Phone Number");
		String mobileNo=sc.next();
		MobileService ms=new MobileService();
		MobileBeans bean=ms.userAccount(mobileNo);
		System.out.println(bean);

	}

}
