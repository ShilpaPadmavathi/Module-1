package com.pdw.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BookDB {
	public  static Connection getConnection1() throws ClassNotFoundException, SQLException {
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	//Create Connection 
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shilpa","shilpa123");
	//create Statement
	
	return conn;
	}
}
