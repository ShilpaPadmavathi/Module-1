package com.pdw.dao;

import com.pdw.beans.BookBean;

public interface BookDaoI {
int addBook(BookBean bookBean);
}
