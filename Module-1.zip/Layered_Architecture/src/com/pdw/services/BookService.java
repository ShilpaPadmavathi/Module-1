package com.pdw.services;

import com.pdw.beans.BookBean;
import com.pdw.dao.BookDAO;

public class BookService implements BookServiceI {
	public int addBook(int bookId,String title,float price) {
		String grade="";
		if(price<=300) {
			grade="c";
		}
		else if(price <= 600) {
			grade= "B";
		}
		else {
			grade="A";
		}
		BookDAO d=new BookDAO();
		BookBean bean=new BookBean();
		bean.setBookId(bookId);
		bean.setTitle(title);
		bean.setPrice(price);
		bean.setGrade(grade);
		int updateResult=0;
		try {
			updateResult=d.addBook(bean);
			return updateResult;
		}
		catch(Exception e) {
			System.out.println(e.toString());
			return 0;
		}
	}

}
