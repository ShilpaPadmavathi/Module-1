package com.pdw.services;

import com.pdw.beans.BookBean;

public interface BookServiceI {
int addBook(int bookId,String title,float price);
}
