package com.pdw.ui;

import java.util.Scanner;

import com.pdw.services.BookService;

public class BookUi {
	public static void main(String[] args) {
		int bookId=0;
		String title="";
		float price=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Book Id");
		bookId=sc.nextInt();
		System.out.println("Enter Book Name");
		title=sc.next();
		System.out.println("Enter Price");
		price=sc.nextFloat();
		
		BookService b=new BookService();
		int finalResult=b.addBook(bookId, title, price);
		System.out.println("record"+finalResult+"Inserted");
		
		
	}
	
	

}
