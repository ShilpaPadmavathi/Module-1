class A1{
	public int balance;
	A1(){
		balance=500000;
	}
	public synchronized void withdraw(int bal) {
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		balance=balance-bal;
		System.out.println("Amount withdrawn="+bal);
		System.out.println("New Balance="+balance);
	}public synchronized void deposit(int bal) {
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		balance=balance+bal;
		System.out.println("Deposited="+bal);
		System.out.println("Available Balance="+balance);
	}
	
		public synchronized void enquiry() {
			try {Thread.sleep(1000);
		}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("Available Balance="+balance);
	}
}
class Transaction implements Runnable{
	A1 obj;
	Transaction(A1 a){obj = a;}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		obj.withdraw(500);
		obj.deposit(100000);
		obj.enquiry();
		
	}
	
}
public class BankEx {
public static void main(String[] args) throws InterruptedException {
	A1 a=new A1();
	Transaction w1=new Transaction(a);
	Thread t1=new Thread(w1);
	Thread t2=new Thread(w1);
	t1.start();
	t2.start();
	t2.join();
}
}
