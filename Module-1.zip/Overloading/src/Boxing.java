import java.util.Scanner;

public class Boxing {
	
	public static void main(String args[]) {
		int a,b;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		/*Integer a1=new Integer(a);
		a1.valueOf(a);
		System.out.println(a1);*/
		
		Integer a2=a;

		Integer b2=b;
		System.out.println("a2 value for boxing is"+a2);
		
		int x=a2.intValue();
		System.out.println(x);
		//auto unboxing
		int y=b2;
		System.out.println("The Value After Unboxing of b is"+b2);
	}

}