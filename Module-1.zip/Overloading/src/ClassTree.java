import java.util.Comparator;
import java.util.TreeSet;
class Tree1 {
	int id;
	String name;
    Tree1(int id,String name){
		this.id=id;
		this.name=name;
	}
    @Override
    public String toString() {
    	
    	return ""+id+""+name ;
    }
}
public class ClassTree {  
	public static void main(String[] args) {
		//TreeSet s=new TreeSet(new Test4());
		//s.add(1221);
		//s.add(1203);
		//s.add(1238);
		//s.add(1204);
		//System.out.println(s);
		//s.add("Shilpa");
		//s.add("Akshitha");
		//s.add("Jyothi");
		//s.add("Mahitha");
		//System.out.println(s);
		//System.out.println("Jyothi".compareTo("Shilpa"));
		//System.out.println("Shilpa".compareTo("Akshitha"));
		//System.out.println("Shilpa".compareTo("Mahitha"));
		Tree1 e1=new Tree1(100,"Shilpa");
		Tree1 e2=new Tree1(200,"Mahitha");
		Tree1 e3=new Tree1(300,"Jyothi");
        Tree1 e4=new Tree1(400,"Akshitha");
		Tree1 e5=new Tree1(500,"Pappu");
		
		TreeSet t1=new TreeSet(new Test4());
		t1.add(e1);
		t1.add(e2);
		t1.add(e3);
		t1.add(e4);
		t1.add(e5);
		System.out.println(t1);
	}

}
class Test4 implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Tree1 e1=(Tree1)o1;
		Tree1 e2=(Tree1)o2;
		Tree1 i1=(Tree1)o1;
		Tree1 i2=(Tree1)o2;
		String s1=e1.name;
		String s2=e2.name;
		Integer i11=i1.id;
		Integer i12=i2.id;
		
		
		/*if(s1<s2)
			return +999;
		else if(i1>i2)
			return -999;
		else
			return 0;*/
		//return -s1.compareTo(s2);
		return -i12.compareTo(i11);
		//return s2.compareTo(s1);
	}
	
}
