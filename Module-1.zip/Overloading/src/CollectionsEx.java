import java.util.ArrayList;
import java.util.LinkedList;

public class CollectionsEx {
	public static void main(String[] args) {
		ArrayList a1=new ArrayList();
		a1.add(1221);
		a1.add(1203);
		a1.add(1238);
		a1.add(1204);
		a1.remove(3);
		//System.out.println(a1);
		ArrayList a2=new ArrayList();
		a2.add("Shilpa");
		a2.add("Pappu");
		a2.add("Soumya");
		a2.add("Bhanu");
		a2.add("Shilpa");
		a1.addAll(a2);
		//System.out.println(a2.get(0));
		a1.add(5,"Padmavathi");
		System.out.println(a1);
		a1.addAll(2,a2);
		System.out.println(a1);
		a1.remove(2);
		System.out.println(a1);
		System.out.println(a1.indexOf("Shilpa"));
		System.out.println(a1.lastIndexOf("Shilpa"));
		
		//System.out.println(a1);
		//System.out.println(a1);
		//a1.removeAll(a2);
		//System.out.println(a1);
		//a1.clear();
		//System.out.println(a1);
		//System.out.println(a1.isEmpty());
		System.out.println(a2.size());
		//System.out.println(a1.removeAll(a2));
		//System.out.println(a1);
		//System.out.println(a1.retainAll(a2));
		//System.out.println(a1);
		//System.out.println(a2);
		System.out.println(a1.containsAll(a2));
		System.out.println(a2.remove("Bhanu"));
		System.out.println(a2);
		LinkedList l1=new LinkedList();
		l1.add("Shilpa");
		l1.add("Akshitha");
		l1.add("Mahitha");
		l1.add("Jyothi");
		System.out.println(l1);
		l1.addFirst("Padmavathi");
		System.out.println(l1);
		l1.addLast("Gorantla");
		System.out.println(l1);
		System.out.println(l1.getFirst());
		System.out.println(l1.getLast());
		System.out.println(l1.removeFirst());
		System.out.println(l1);
		System.out.println(l1.removeLast());
		System.out.println(l1);
	}

}
