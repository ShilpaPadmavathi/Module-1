import java.util.Vector;

public class CollectionsEx1 {
	public static void main(String[] args) {
		Vector v=new Vector();
		v.addElement("Shilpa");
		v.addElement("Jyothi");
		v.addElement("Akshitha");
		v.add("Mahitha");
		v.add("Pop");
		System.out.println(v);
		v.removeElement("Pop");
		System.out.println(v);
		v.removeElementAt(3);
		System.out.println(v);
		System.out.println(v.elementAt(0));
		System.out.println(v.firstElement());
		System.out.println(v.lastElement());
		System.out.println(v.size());
		System.out.println(v.capacity());
		v.removeAllElements();
		System.out.println(v);
		
	}

}
