import java.util.concurrent.ConcurrentHashMap;
public class ConcurrentHashMaps {
	public static void main(String[] args) {
		ConcurrentHashMap hc=new ConcurrentHashMap();
		hc.put(1221,"Shilpa");
		hc.put(1203, "Pappu");
		hc.put(1238, "Soumya");
		hc.putIfAbsent(1204,"Bhanu");
		System.out.println(hc);
		boolean b=hc.remove(1204, "Bhanu");
		System.out.println(hc.remove(1204, "Bhanu"));
		System.out.println(hc);
		System.out.println(hc.replace(1238, "Soumya","Shilpa"));
		System.out.println(hc);
	}
}
