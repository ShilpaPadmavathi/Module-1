import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
public class ConcurrentHashMaps1 extends Thread {
	static HashMap hx=new HashMap();
	public void run(){
		try {
			Thread.sleep(100000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Child");
		hx.put(1238, "Soumya");
		
	}
	public static void main(String[] args) throws InterruptedException {
	hx.put(1221,"Shilpa");
	hx.put(1203,"Pappu");
	ConcurrentHashMaps1 t=new ConcurrentHashMaps1();
	t.start();
	Set s=hx.keySet();
	Iterator itr=s.iterator();
	while(itr.hasNext()) {
		Integer i=(Integer) itr.next();
		System.out.println("Main Thread");
		System.out.println("Current Key is"+i+"and Value is"+hx.get(i));
		Thread.sleep(1000);}
		System.out.println(hx);
	}
	
}