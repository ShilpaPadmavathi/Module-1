import java.util.Date;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class ConsumerEg {
	public static void main(String[] args) {
		Consumer<String>con=i->System.out.println(i);
		con.accept("Welcome to Capgemini");
		con.accept("Shilpa");
		Supplier<Date> d=()->new Date();
		System.out.println(d.get());
		Supplier<String> sup=()->{
			String otp=" ";
			for(int i=0;i<6;i++) {
				otp=otp+(int)(Math.random()*10);
			}
			return otp;
		};
		System.out.println(sup.get());
		String s="Shilpa";
		Function<String,String> f=i->i.toUpperCase();
		System.out.println(f.apply(s));
		String s1="Shilpa";
		Function<String,Integer> s11=i->s1.length();
		System.out.println(s11.apply(s1));
		
		
	}
}
