import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayList1{
	public static void main(String[] args) {
		ArrayList l=new ArrayList();
		CopyOnWriteArrayList cowa=new CopyOnWriteArrayList();
		l.add(658);
		l.add(565);
		l.add(654);
		l.add(543);
		cowa.add(1221);
		cowa.add(1203);
		cowa.add(1238);
		cowa.add(1204);
		cowa.addIfAbsent(1204);
		cowa.addAllAbsent(l);
		System.out.println(cowa);

	}
	
}
