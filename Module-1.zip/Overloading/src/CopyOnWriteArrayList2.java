import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;


public class CopyOnWriteArrayList2 extends Thread {

	static CopyOnWriteArrayList al=new CopyOnWriteArrayList();
	public void run(){
		try {
			Thread.sleep(1000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Child");
		al.add(1238);
		
	}
	public static void main(String[] args) throws InterruptedException {
	al.add(1221);
	al.add(1203);
	CopyOnWriteArrayList2 t=new CopyOnWriteArrayList2();
	t.start();
	Iterator itr=al.iterator();
	while(itr.hasNext()) {
		Integer i=(Integer) itr.next();
		System.out.println("Main Thread");
		System.out.println("Main Thread is Iterating"+i);
		Thread.sleep(1000);
		System.out.println(al);
	}}
	
}

