class OddOrEven{
	public int n;
	public boolean value=false;
synchronized void odd(int n) {
if(value) {
	try {
		wait();
	}
	catch(InterruptedException e) {
		e.printStackTrace();
	}}
	this.n=n;
	System.out.println(n);
	value=true;
	notify();
}
synchronized void even(int n) {
	if(!value) {
		try {
			wait();
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}}
		this.n=n;
		System.out.println(n);
		value=false;
		notify();
	
}}
class Odd implements Runnable{
	OddOrEven num;
	Odd(OddOrEven num){
		this.num=num;
		Thread t=new Thread(this,"Even");
		t.start();
	}
	@Override
	public void run() {
		for(int i=1;i<=100;i=i+2) {
			num.odd(i);
		}}
		
	}
class Even implements Runnable{
	OddOrEven num;
	Even(OddOrEven num){
		this.num=num;
		Thread t=new Thread(this,"Even");
		t.start();
	}
	@Override
	public void run() {
		for(int i=2;i<=100;i=i+2) {
			num.even(i);
		
		}
		
	}
	
}
public class EvenOddInter {
public static void main(String[] args) {
	OddOrEven number=new OddOrEven();
	Even e=new Even(number);
	//System.out.println("Hello");
	Odd d=new Odd(number);	
}	
}
