import java.util.Scanner;
class Call{
	public void div() throws Exception{
		int c1=10,c2=0;
		int d1=c1/c2;
		System.out.println(d1);
	}
}
public class Exceptions {
	public static void main(String args[]) {
	int a,b;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter First Number");
	a=sc.nextInt();
	System.out.println("Enter Second Number");
	b=sc.nextInt();
	try {
		int c=a/b;
		
	}
	catch(Exception e) {
		System.out.println("Donot Enter ZERO as Denominator");
		System.out.println(e);
		e.printStackTrace();
		System.out.println(e.getMessage());
	}
	try {
		int a1[]=new int[5];
		a1[0]=2;
		//a1[0]=2/0;
		a1[7]=5;
	}
	catch(ArithmeticException e) {
		System.out.println("ARITHMETIC EXCEPTION");
	}
	catch(Exception ex){
		System.out.println("ARRAY INDEX OUT OF BOUNDS EXCEPTION");
	}
	try {
		int a2=211;
		try {
			int c=a2/0;
		}
		catch(Exception e) {
			System.out.println("ARITHMETIC EXCEPTION");
		}
		try {
			int c=a2%'d';
			System.out.println(c);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	finally{
		System.out.println("NO ERRORS ARE FOUND");
	}
	Call c1=new Call();
	try {
		c1.div();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		System.out.println("THIS IS THROWS EXCEPTIONS ");;
		
	}
	sc.close();
	//System.out.println("REMAINING LINES");
	}

}
