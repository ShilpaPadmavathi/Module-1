class D{
	int a=222;
	public void s() {
		a=a+200;
		System.out.println(a);
	}
}
class Final extends D{
public void s() {
	a=a-150;
	System.out.println(a);
}
public static void main(String args[]) {
	Final f=new Final();
	f.s();
}
}
