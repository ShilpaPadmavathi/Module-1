
public class Get_Set {
	
	private int eid=1020;
	private String ename="SHILPA";
	private int apin;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	/*public int getApin() {
		return apin;
	}*/
	public void setApin(int apin) {
		this.apin = apin;
	}
	

}
