
public class Getters_Setters {

	static Get_Set g=new Get_Set();
	public static void main(String args[]) {
		System.out.println(g.getEid());
		System.out.println(g.getEname());
		g.setEid(123);
		g.setEname("SHILPA");
		System.out.println("************************");
		System.out.println(g.getEid());
		System.out.println(g.getEname());
	}
	
	
	
}
