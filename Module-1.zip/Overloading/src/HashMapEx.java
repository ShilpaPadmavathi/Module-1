import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class HashMapEx {
	
	public static void main(String[] args) {
		//HashMap hx=new HashMap();
		//LinkedHashMap hx1=new LinkedHashMap();
		TreeMap t1=new TreeMap();
		t1.put(1221, "Shilpa");
		t1.put(1203, "Pappu");
		t1.put(1238, "Soumya");
		t1.put(1204, "Bhanu");
		System.out.println(t1);
		//HashMap hx1=new HashMap();
		TreeMap t2=new TreeMap();
		t2.put(121, "Shilpa");
		t2.put(122, "Jyothi");
		t2.put(123, "Mahitha");
		t2.put(124, "Akshitha");
		t1.putAll(t2);
		
		/*LinkedHashMap hx2=new LinkedHashMap();
		hx2.put(121, "Shilpa");
		hx2.put(122, "Jyothi");
		hx2.put(123, "Mahitha");
		hx2.put(124, "Akshitha");
		hx1.putAll(hx2);*/
		System.out.println(t1);
		System.out.println(t2.get(123));
		System.out.println(t1.remove(1204));
		System.out.println(t1.containsKey(1221));
		System.out.println(t2.containsValue("Bhanu"));
		System.out.println(t1.isEmpty());
		System.out.println(t1.size());
		//t1.clear();
		//System.out.println(t1);
		System.out.println(t1.keySet());
		System.out.println(t1.entrySet());
		System.out.println(t1.values());
		
	}

}
