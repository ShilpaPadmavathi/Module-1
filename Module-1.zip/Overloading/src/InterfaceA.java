
public interface InterfaceA {
	
	public void m1();
	default void m2() {
		System.out.println("Hello Hai");
	}
	static void m3() {
		System.out.println("Bye Bye");
	}
	

}
