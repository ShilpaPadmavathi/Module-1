import java.util.function.Predicate;

public class Java8 {

	/*@Override
	public void m1() {
		System.out.println("Hello Haii");
		
	}*/
	
	public static void m2() {
		System.out.println("Bye Bye");
	}
	public static void main(String[] args) {
		Java8 j=new Java8();
		//j.m1();
		j.m2();
		InterfaceA.m3();
		Predicate<Integer> p=i->i%2==0;
		System.out.println(p.test(10));
		System.out.println(p.test(1221));
		InterfaceA a2=Java8::m2;
		
		
		
		
	}
	
	

}
