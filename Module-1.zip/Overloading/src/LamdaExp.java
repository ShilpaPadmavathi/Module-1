import java.util.Scanner;

interface Lamdae{
	public int add(int a,int b);
}

/*public class LamdaExp{
	
	public static void main(String[] args) {
		int a1=9;
		int b1=0;
		System.out.println("Hello");
		Lamdae lam=(a,b)->{return (a+b);};
		System.out.println(lam.add(a1, b1));
	}*/

/*interface Length{
	
	public int len(String s);
}
public class LamdaExp{
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Hello");
		String s1=sc.next();
		Length l=(s)->s.length();
		System.out.println(l.len(s1));
		
	}
	

}*/

/*public class LamdaExp implements Runnable{
	@Override
	public void run() {
		System.out.println("Hello Hai This is Shilpa");
		
	}
	public static void main(String[] args) {
		LamdaExp e=new LamdaExp();
		Thread t=new Thread(e);
		t.start();
	}
}*/
class LamdaExp{
	public static void main(String[] args) {
		Runnable r=()->{System.out.println("Hello Hai Bye Bye");};
		Thread t=new Thread(r);
		t.start();
		System.out.println("Hello");
	}
}
