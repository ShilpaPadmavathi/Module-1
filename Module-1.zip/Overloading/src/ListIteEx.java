import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteEx {
public static void main(String[] args) {
	ArrayList<String> ar=new ArrayList<String>();
	ar.add("Shilpa");
	ar.add("Jyothi");
	ar.add("Akshitha");
	ar.add("Mahitha");
	System.out.println(ar);
	ListIterator itr1=ar.listIterator();
	while(itr1.hasNext()) {
		System.out.println(itr1.next()+" ");
	}
	while(itr1.hasPrevious()) {
		String val=(String)itr1.previous();
		if(val.equals("Jyothi"))
		{
		itr1.set("Capgemini");
		System.out.println(itr1.next());
		itr1.previous();
		}
		else {
			System.out.println(val);
			
		}
		//System.out.println(itr1.previous()+" ");
	}
}
}
