class A{
	public void sub()
	{
		System.out.println("This is NORMAL");
	}
	public int sub(int a,int b) {
		return a-b;
	}
	public int sub(int b,int a,int c) {
		return b-a+c;
	}
	public void sub(float a,int b) {
		System.out.println(a-b);
	}
	public float sub(float a,float b) {
		return a-b;
	}
}
public class Overloading {
public static void main(String args[]) {
	A o=new A();
	o.sub();
	int c=o.sub('d','a');
	System.out.println(c);
	System.out.println(o.sub(50,30,20));
	System.out.println(o.sub(50.20f,30.20f));
}
}
