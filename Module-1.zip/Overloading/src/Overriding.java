class B{
	public void s() {
		System.out.println("This is MINE");
	}
   public void s1() {
		System.out.println("This is NOT MINE");
	}
	
}
public class Overriding extends B{

public void s1() {
	System.out.println("This is ALSO MINE");
}
public static void main(String args[]) {
	Overriding s=new Overriding();
	s.s();
	s.s1();
}
}
