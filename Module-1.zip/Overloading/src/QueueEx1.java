import java.util.Iterator;
import java.util.PriorityQueue;

public class QueueEx1 {
public static void main(String[] args) {
	PriorityQueue<String> queue=new PriorityQueue<String>();
	queue.add("Shilpa");
	queue.add("Akshitha");
	queue.add("Jyothi");
	queue.add("Mahitha");
	System.out.println(queue);
	System.out.println(queue.element());
	System.out.println(queue.peek());
	System.out.println(queue.poll());
	System.out.println(queue.remove());
	System.out.println(queue);
	Iterator itr=queue.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
}
}
