import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;
public class SetEx {	
	public static void main(String[] args) {
		HashSet h=new HashSet();
		h.add("Shilpa");
		h.add("Mahitha");
		h.add("Jyothi");
		h.add("Akshitha");
		System.out.println(h);
		LinkedHashSet h1=new LinkedHashSet();
		h1.add("Shilpa");
		h1.add("Mahitha");
		h1.add("Jyothi");
		h1.add("Akshitha");
		System.out.println(h1);
		TreeSet h2=new TreeSet();
		h2.add("Shilpa");
		h2.add("Mahitha");
		h2.add("Jyothi");
		h2.add("Akshitha");
		System.out.println(h2);
	}
	
	}
