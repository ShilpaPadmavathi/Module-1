import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import org.omg.Messaging.SyncScopeHelper;
/*class StreamAi{
	private int id;
	private String name;
	private int sal;
	public StreamAi(int id, String name, int sal) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " "+id+" "+name+" "+sal;
	}}*/
public class StreamApiEx {
public static void main(String[] args) {
	ArrayList<Integer> al=new ArrayList<Integer> ();
	al.add(1221);
	al.add(1203);
	al.add(1238);
	List<Integer> l=(List<Integer>) al.stream().filter(i->i%2==0).collect(Collectors.toList());
	System.out.println(l);
	List<Integer> l1=(List<Integer>) al.stream().filter(i->i<1238).collect(Collectors.toList());
	System.out.println(l1);
	long l2=(long) al.stream().filter(i->i<1238).count();
	System.out.println(l2);
	List<Integer> l3=(List<Integer>) al.stream().map(i->i+25).collect(Collectors.toList());
	System.out.println(l3);
	List<Integer> l4=(List<Integer>)al.stream().sorted().collect(Collectors.toList());
	System.out.println(l4);
	List<Integer> l5= al.stream().sorted((i1,i2)->(i1<i2)?1:(i1>i2)?-1:0).collect(Collectors.toList());
	System.out.println(l5);
	Integer l6=al.stream().min((i1,i2)->-i1.compareTo(i2)).get();
	System.out.println(l6);
	Integer l7=al.stream().max((i1,i2)->-i2.compareTo(i1)).get();
	System.out.println(l7);
	al.stream().forEach(i->{
		System.out.println(i);
	});
	al.stream().forEach(System.out::println);
}
}