
public class Strings {
public static void main(String args[]) {
	/*String s1="SHILPA";
	String s2="SHILPA";
	System.out.println(s1.equals(s2));
	System.out.println(s1==s2);
	String s3=new String("SHILPA");
	String s4=new String("SHILPA");
	System.out.println(s3.equals(s4));
	System.out.println(s3==s4);*/
	StringBuffer sb=new StringBuffer("PADMAVATHI");
	StringBuffer sb1=new StringBuffer("PADMAVATHI");
	System.out.println(sb.equals(sb1));
	System.out.println(sb==sb1);
	//sb.append("GORANTLA");
	System.out.println(sb);
	String s5=sb.toString();
	String s6=sb1.toString();
	System.out.println(s5.equals(s6));
	System.out.println(s5==s6);
	
	
	
}
}
