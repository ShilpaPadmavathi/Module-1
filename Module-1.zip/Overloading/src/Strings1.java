
public class Strings1 {
	public static void main(String args[]) {
		char s2[]= {'a','b','c'};
		String s="SHILPA GORANTLA";
		String s1="PADMAVATHI";
		StringBuffer b=new StringBuffer("GORANTLA");
		System.out.println(s.length());
		System.out.println(s.isEmpty());
		System.out.println(s.codePointAt(5));
		System.out.println(s.codePointBefore(5));
		System.out.println(s.codePointCount(0, 5));
		System.out.println(s.offsetByCodePoints(0,2));
		System.out.println(s1.equals(s2));
		System.out.println(s.contentEquals(s1));
		System.out.println(s.equalsIgnoreCase("Shilpa"));
		System.out.println(s.compareTo("Shilpa"));
		System.out.println(s.compareToIgnoreCase("Shilpa"));
		System.out.println(s.regionMatches(0, "SHILPA", 0, 5));
		System.out.println(s.startsWith("SHILPA",1));
		System.out.println(s.startsWith(s1));
		System.out.println(s.endsWith(s1));
		System.out.println(s1.hashCode());
		System.out.println(s.indexOf('I'));
		System.out.println(s1.indexOf('A', 0));
		System.out.println(s.lastIndexOf('s'));
		System.out.println(s.substring(6));
		System.out.println(s.substring(6,12));
		System.out.println(s.subSequence(6,11));
		System.out.println(s.concat(s1));
		System.out.println(s.replace(s,s1));
		System.out.println(s.matches(s1));
		System.out.println(s.toLowerCase());
		System.out.println(s1.toUpperCase());
		System.out.println(s.trim());
		//System.out.println(s.valueOf("H"));
		System.out.println(s.replaceFirst(s, s1));
		System.out.println(s.replaceAll(s1, s));
		System.out.println(s1.concat(s));
		System.out.println(s.matches(s));
		System.out.println(s.compareTo(s));
		System.out.println(s.subSequence(2, 5));
		System.out.println(s.contains("ILP"));
		//System.out.println(s.split("S"));
		System.out.println(s.intern());
		
		
		
		
	}

}
