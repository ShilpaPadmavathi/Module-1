class ThreadEx3{
	
	public synchronized void display(String msg) {
		System.out.println("["+msg);
		try {Thread.sleep(3000);}catch(InterruptedException e) {e.printStackTrace();}
		System.out.println("]");
	}
	
}

class ThreadEx1 extends Thread {
	String msg;
	ThreadEx3 fobj;
	ThreadEx1(ThreadEx3 fobj,String msg){
		this.fobj=fobj;
		this.msg=msg;
		this.start();
	}
	public void run() {
		fobj.display(msg);
	}}

public class SynchronizedEx {
	public static void main(String[] args) {
		ThreadEx3 fnew=new ThreadEx3();
		ThreadEx1 ss=new ThreadEx1(fnew,"Welcome");
		ThreadEx1 ss1=new ThreadEx1(fnew,"TO");
		ThreadEx1 ss2=new ThreadEx1(fnew,"Chennai");
		
		
	}
	

}
