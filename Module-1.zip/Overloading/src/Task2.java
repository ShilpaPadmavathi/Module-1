public class Task2 {
private int empid;
private String ename;
private int sal;
public Task2(int empid, String ename, int sal) {
	super();
	this.empid = empid;
	this.ename = ename;
	this.sal = sal;
}
@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ""+empid+ ""+ename+ ""+sal;
	}



}
