import java.util.ArrayList;
import java.util.Iterator;

public class Task3 {
public static void main(String[] args) {
	//Task2 t=new Task2();
	Task2 t=new Task2(123,"Shilpa",200000);
	Task2 t1=new Task2(124,"Akshitha",20000);
	Task2 t2=new Task2(125,"Jyothi",20000);
	Task2 t3=new Task2(126,"Mahitha",20000);
	ArrayList<Task2> b=new ArrayList<Task2>();
	b.add(t);
	b.add(t1);
	b.add(t2);
	b.add(t3);
	System.out.println(b);
	Iterator itr1=b.iterator();
	while(itr1.hasNext()) {
		System.out.println(itr1.next());
	}
	
	
}
}
