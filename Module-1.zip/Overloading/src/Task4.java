import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;
class Test1{
	String actype;
	String name;
	int balance;
	Test1(String actype,String name,int balance){
		this.actype=actype;
		this.name=name;
		this.balance=balance;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ""+actype+""+name+""+balance;
	}
	public String getActype() {
		return actype;
	}

	public void setActype(String actype) {
		this.actype = actype;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
}

public class Task4 {
	
public static void main(String[] args) {
	HashMap hx=new HashMap();
	Test1 t1=new Test1("Post-paid", "Shilpa", 200);
	Test1 t2=new Test1("Pre-paid", "Jyothi", 300);
	Test1 t3=new Test1("Post-paid", "Mahitha", 350);
	Test1 t4=new Test1("Pre-paid", "Akshitha", 500);
	hx.put("8317580045", t1);
	hx.put("9840291500",t2);
	hx.put("9789850682",t3);
	hx.put("8125199885",t4);
	System.out.println(hx);
	System.out.println("1. Display");
	System.out.println("2. Add");
	Scanner sc=new Scanner(System.in);
	int d=sc.nextInt();
	switch(d) {
	case 1:String num1=sc.next();
	Test1 t=(Test1) hx.get(num1);
	System.out.println(t);
	break;
	case 2:int bal=sc.nextInt();
	String num2=sc.next();
	Test1 t0=(Test1) hx.get(num2);
	int c=t0.getBalance();
	int d1=bal+c;
	System.out.println(d1);
	System.out.println("Recharge done successfully");
	break;
	default:System.out.println("Invalid input");
	
	}
	
}
}
