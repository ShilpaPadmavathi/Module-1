import java.util.Scanner;

public class TaskStrings {
	
	public static void main(String[] args) {
		int n;
		int count=0;
		char ch=' ';
		String s1,s3 = "Padmavathi";
		Scanner sc=new Scanner(System.in);
		//System.out.println("Enter Index");
		//n=sc.nextInt();
		System.out.println("Enter String");
		s1=sc.nextLine();
		System.out.println(s1);
		System.out.println(s1.charAt(2));
		System.out.println(s1.regionMatches(0, s1, 2,3));
		String s2=s1.toUpperCase();
		System.out.println(s2.charAt(2));
		System.out.println(s1.substring(0, 6).toUpperCase());
		System.out.println(s1.endsWith(s3));
		}
		}


