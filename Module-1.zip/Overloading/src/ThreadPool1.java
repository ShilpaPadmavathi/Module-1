import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ThreadPool1 {
	public static void main(String[] args) {
		ScheduledExecutorService service=Executors.newScheduledThreadPool(10);
		service.schedule(new Thread2(), 15, TimeUnit.SECONDS);
		service.scheduleAtFixedRate(new Thread2(), 15, 10, TimeUnit.SECONDS);
		
		service.scheduleWithFixedDelay(new Thread2(), 15, 10,TimeUnit.SECONDS);
	}

}
class Thread2 implements Runnable{

	@Override
	public void run() {
		System.out.println("Hai This Is SHILPA");
		
	}
	
}
