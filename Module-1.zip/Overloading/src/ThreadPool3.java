import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadPool3 {
	
	public static void main(String[] args) throws InterruptedException,ExecutionException{
		ExecutorService service= Executors.newFixedThreadPool(2);
		List<Future> allFutures=new ArrayList();
		for(int i=0;i<100;i++) {
			Future future=service.submit(new Task51());
			allFutures.add(future);
		}
		for(int i=0;i<100;i++) {
			Future<Integer> future=allFutures.get(i);
			Integer result=future.get();
			System.out.println(result);
		}
	}
}

	class Task51 implements Callable<Integer>{

		@Override
		public Integer call() throws Exception {
			// TODO Auto-generated method stub
			Thread.sleep(3000);
			return new Random().nextInt();
		}
		
	}
