class ThreadEx implements Runnable{
	@Override
	public void run() {
		
		for(int i=1;i<10;i++)
			System.out.println("HELLO HAII SHILPA");
		// TODO Auto-generated method stub
		
	}
	
}
/*class ThreadEx1 extends Thread{
	@Override
	public void run() {
		for(int i=1;i<10;i++)
			System.out.println("Hello Haii"+Thread.currentThread());
		
	}
}*/
public class Threads1 {
public static void main(String[] args) throws InterruptedException {
	for(int i=0;i<5;i++)
	{
		Thread.currentThread().setName("Shilpa");
		System.out.println("Shilpa");
		Thread.currentThread().setPriority(10);
		//System.out.println(Thread.currentThread());
	}
	ThreadEx t=new ThreadEx();
	Thread t1=new Thread(t);
	//ThreadEx1 t2=new ThreadEx1();
	t1.start();
	t1.join();
	//t1.start();
}	
}
