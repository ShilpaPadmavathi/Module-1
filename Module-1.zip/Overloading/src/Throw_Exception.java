class Test extends Exception{
	private int age;
	Test(int age){
		this.age=age;
	}
	public String toString() {
		return "YOU ARE NOT ELIGIBLE TO VOTE";
	}
}
public class Throw_Exception {
	static void valid(int age) throws Test{
		if(age<18)
			throw new Test(age);
		else
			System.out.println("YOU ARE ELIGIBLE TO VOTE");
	}
	public static void main(String args[]) throws Test{
		Throw_Exception.valid(16);
		System.out.println("REST OF CODE");
	}
	
}
