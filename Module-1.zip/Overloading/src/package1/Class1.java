package package1;
class Class1 {
void pack1() {
	System.out.println("THIS IS PACKAGE1");
}
}
