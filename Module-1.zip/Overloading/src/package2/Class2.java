package package2;
class Class_A{
	protected void m1() {
		System.out.println("THIS IS PRIVATE");
	}
}
public class Class2 extends Class_A {
public static void main(String args[]) {
	Class_A a=new Class_A();
	a.m1();
}

}
