package com.capg.frs.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.capg.frs.dto.FlatOwner;
import com.capg.frs.dto.FlatRegistrationDTO;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO{
	Map<Integer,FlatOwner>owners;
	FlatRegistrationDTO frd;
	public FlatRegistrationDAOImpl(){
		owners=new HashMap();
	}
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		owners.put(1,new FlatOwner(1,"Vaishali","9023002122")); 
		owners.put(2,new FlatOwner(2,"Megha","9643221234"));
		owners.put(1,new FlatOwner(3,"Manish","5453221234"));  
		return flat;
	}
	@Override
	public ArrayList<FlatRegistrationDTO> getFlatDetails(FlatRegistrationDTO dto) {
		HashMap reg=new HashMap();
		reg.put(dto.getId(),dto);
		frd = (FlatRegistrationDTO) reg.get(dto);
		Set s=reg.entrySet();
		ArrayList<FlatRegistrationDTO> al = new ArrayList(s);
		return al;
	}
	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		// TODO Auto-generated method stub
		return null;
	}

}
