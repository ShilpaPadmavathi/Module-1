package com.capg.frs.dao;

import java.util.ArrayList;

import com.capg.frs.dto.FlatRegistrationDTO;

public interface IFlatRegistrationDAO {
	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat);
	ArrayList<Integer>getAllOwnerIds();
	ArrayList<FlatRegistrationDTO> getFlatDetails(FlatRegistrationDTO dto);

}
