package com.capg.frs.dto;

public class FlatOwner {
		int id;
		String name;
		String mobileNum;
		public FlatOwner(int id, String name, String mobileNum) {
			super();
			this.id = id;
			this.name = name;
			this.mobileNum = mobileNum;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getMobileNum() {
			return mobileNum;
		}
		public void setMobileNum(String mobileNum) {
			this.mobileNum = mobileNum;
		}
		@Override
		public String toString() {
			return "FlatOwner [id=" + id + ", name=" + name + ", mobileNum=" + mobileNum + "]";
		}

}
