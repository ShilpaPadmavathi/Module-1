package com.capg.frs.dto;

public class FlatRegistrationDTO {
	private int id;
	private int fType;
	private int fArea;
	private float dAmount;
	private float depositAmt;
	public FlatRegistrationDTO(int id, int fType, int fArea, float dAmount, float depositAmt) {
		super();
		this.id = id;
		this.fType = fType;
		this.fArea = fArea;
		this.dAmount = dAmount;
		this.depositAmt = depositAmt;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getfType() {
		return fType;
	}
	public void setfType(int fType) {
		this.fType = fType;
	}
	public int getfArea() {
		return fArea;
	}
	public void setfArea(int fArea) {
		this.fArea = fArea;
	}
	public float getdAmount() {
		return dAmount;
	}
	public void setdAmount(float dAmount) {
		this.dAmount = dAmount;
	}
	public float getDepositAmt() {
		return depositAmt;
	}
	public void setDepositAmt(float depositAmt) {
		this.depositAmt = depositAmt;
	}
	@Override
	public String toString() {
		return "FlatRegistrationDTO [id=" + id + ", fType=" + fType + ", fArea=" + fArea + ", dAmount=" + dAmount
				+ ", depositAmt=" + depositAmt + "]";
	}
}
