package com.capg.frs.service;

import java.util.ArrayList;
import java.util.List;

import com.capg.frs.dao.FlatRegistrationDAOImpl;
import com.capg.frs.dto.FlatOwner;
import com.capg.frs.dto.FlatRegistrationDTO;
public class FlatRegistrationServiceImpl implements IFlatRegistrationService{
	FlatRegistrationDAOImpl dao =new FlatRegistrationDAOImpl();
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		
		FlatRegistrationDTO f=dao.registerFlat(flat);
		return f;
	}
	@Override
	public List getFlatDetails(FlatRegistrationDTO dto) {
		List l=dao.getFlatDetails(dto);
		return l;
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
