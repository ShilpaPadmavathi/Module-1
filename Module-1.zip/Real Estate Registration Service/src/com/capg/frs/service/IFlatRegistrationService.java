package com.capg.frs.service;

import java.util.ArrayList;
import java.util.List;

import com.capg.frs.dto.FlatRegistrationDTO;

public interface IFlatRegistrationService {
	
	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat);
	ArrayList<Integer> getAllOwnerIds();
	List getFlatDetails(FlatRegistrationDTO dto);

}
