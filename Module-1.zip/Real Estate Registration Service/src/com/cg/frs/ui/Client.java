package com.cg.frs.ui;

import java.util.List;
import java.util.Scanner;

import com.capg.frs.dto.FlatRegistrationDTO;
import com.capg.frs.service.FlatRegistrationServiceImpl;

public class Client {
public static void main(String[] args) {
	FlatRegistrationDTO dto = null;
	FlatRegistrationServiceImpl reg=new FlatRegistrationServiceImpl();
	int id;
	int fId = 0;
	int fType;
	int fArea;
	float dAmount;
	float depositAmt;
	System.out.println("1. Register Flat");
	System.out.println("2. Display Flat Registration Details");
	System.out.println("3. Exit");
	while(true) {
		System.out.println("Enter Your Choice");
		Scanner sc=new Scanner(System.in);
		int d=sc.nextInt();
		switch(d) {
		case 1:
		System.out.println("Existing Owner IDS Are:-[1,2,3]");
		System.out.println("Please Enter your owner id from above list:");
		id=sc.nextInt();
		System.out.println("Select Flat Type(1-1BHK,2-2BHK):");
		fType=sc.nextInt();
		System.out.println("Enter Flat Area in sq.ft:");
		fArea=sc.nextInt();
		System.out.println("Enter desired rent amount:");
		dAmount=sc.nextFloat();
		System.out.println("Enter desired deposit amount:");
		depositAmt=sc.nextFloat();
		for(int i=0;i<4;i++) {
			fId=fId+(int)(Math.random()*10);
		}
		dto=new FlatRegistrationDTO(fId,fType,fArea,dAmount,depositAmt);
		FlatRegistrationDTO r1=reg.registerFlat(dto);
		System.out.println("Flat Successfully Registered. Registration id:"+fId);
		break;
		case 2:System.out.println("Enter Your Registration Id");
		id=sc.nextInt();
		List l= (List) reg.getFlatDetails(dto);
		System.out.println("Your details are"+l+'\n');
		break;
		case 3:System.exit(0);
	}}
}
}
