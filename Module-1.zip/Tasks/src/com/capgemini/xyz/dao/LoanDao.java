package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Customer.Loan;

public class LoanDao implements ILoanDao{
	private Map<Long,Customer>customerEntry;
	private Map<Integer,Loan>loanEntry;
	public LoanDao(){
		customerEntry=new HashMap();
		loanEntry=new HashMap();
	}
	@Override
	public long applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public long insertCust(Customer cust) {
		customerEntry.put(cust.getCustId(), cust);
		long l=cust.getCustId();
		System.out.println(cust.getCustId());
		return l;
	}
}
