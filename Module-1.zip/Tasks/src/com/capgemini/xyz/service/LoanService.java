package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Customer.Loan;
import com.capgemini.xyz.dao.LoanDao;

public class LoanService implements ILoanService {
	LoanDao d=new LoanDao();

	@Override
	public long applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer validateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long insertCust(Customer cust) {
		long l=d.insertCust(cust);
		return l;
	}
	

}
