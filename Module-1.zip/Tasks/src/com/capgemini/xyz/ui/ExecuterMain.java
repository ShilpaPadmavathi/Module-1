package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {
	public static void main(String[] args) {
		LoanService s=new LoanService();
		Customer c;
		String custId = "";
		System.out.println("XYZ Finance Company Welcomes You");
		System.out.println("1. Register Customer");
		System.out.println("2. Exit");
		Scanner sc=new Scanner(System.in);
		int d=sc.nextInt();
		switch(d) {
		case 1: System.out.println("Enter Customer Name");
		String s1=sc.next();
		System.out.println("Enter Address");
		String s2=sc.next();
		System.out.println("Enter Email");
		String s3=sc.next();
		for(int i=0;i<6;i++) {
			custId=custId+(int)(Math.random()*10);
		}
		System.out.println(custId);
		System.out.println("Enter Mobile");
		long mobile=sc.nextLong();
		long custId1=Long.parseLong(custId);
		c=new Customer(custId1,s1,s2,mobile,s3);
		long l=s.insertCust(c);
		break;
		
		}
		
		
	}

}
