package task;

public class EmployeeBean {
	int Empid;
	String name;
	float sal;
	public EmployeeBean(String name, float sal) {
		super();
		this.name = name;
		this.sal = sal;
	}
	public EmployeeBean() {
		// TODO Auto-generated constructor stub
	}
	public int getEmpid() {
		return Empid;
	}
	public void setEmpid(int empid) {
		Empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSal() {
		return sal;
	}
	public void setSal(float sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " "+name+" "+sal;
	}
	

}
