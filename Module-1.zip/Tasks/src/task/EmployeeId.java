package task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class EmployeeId  {
	public static void main(String[] args) {
		EmployeeBean eb=new EmployeeBean();
		HashMap<Integer, EmployeeBean> hx=new HashMap<Integer, EmployeeBean>();
		EmployeeBean eb1=new EmployeeBean("Shilpa",200000);
		EmployeeBean eb2=new EmployeeBean("Akshitha",200000);
		hx.put(1, eb1);
		hx.put(2,eb2);
		System.out.println("Hello");
		Set s=hx.entrySet();
		ArrayList<EmployeeBean> l=new ArrayList<EmployeeBean>(s);
		Iterator<EmployeeBean> i=l.iterator();
		System.out.println("Hello");
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}
}
