package task;
import java.util.ArrayList;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
public class TaskOnPredicate {
	public static void main(String[] args) {
	ArrayList<Employee> al=new ArrayList();
	al.add(new Employee(1221,"Shilpa",200000));
	al.add(new Employee(1203,"Pappu",10000));
	al.add(new Employee(1238,"Soumya",2000));
	Predicate<Employee> p=e->e.sal>3000;
	String str[]= {"Shilpa","Pappu","Soumya","Aks","Illu","max"};
	Predicate<String> p1=s->s.length()%2==0;
	BiPredicate<Integer,Integer> bip=(a,b)->(a+b)%2==0;
	System.out.println(bip.test(21, 24));
	BiConsumer<Employee,Integer> bic=(emp,sal1)->emp.sal=emp.sal+sal1;
	for(Employee e1:al) {
		bic.accept(e1, 10000);
	}
	BiFunction<Employee,Integer,Integer> bif=(emp,sal1)->emp.sal=emp.sal+sal1;
	for(Employee e1:al) {
		System.out.println(bif.apply(e1, 10000));
	}
	
	for(String s1:str)
	if(p1.test(s1)) {
		System.out.println(s1);
	}
	int x[]= {10,20,30,40,50,5};
	Predicate<Integer> p2=i->i%2==0;
	Predicate<Integer> p3=i->i>10;
	for(int i1:x) {
		/*if(p2.and(p3).test(i1)) {
			System.out.println(i1);
		}
		if(p2.or(p3).test(i1)) {
			System.out.println(i1);
		}*/
		if(p2.negate().test(i1)) {
			System.out.println(i1);
		}
	}
	for(Employee e1:al) {
		if(p.test(e1)) {
		System.out.println(e1.ename+" "+e1.eid+" "+e1.sal);
	}}
}}
class Employee{
	int eid;
	String ename;
	int sal;
	public Employee(int eid, String ename, int sal) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.sal = sal;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " "+eid+" "+ename+" "+sal;
	}
}
