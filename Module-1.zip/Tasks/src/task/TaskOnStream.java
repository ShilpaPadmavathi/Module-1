package task;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
/*class Data{
	Integer data;
	Data(Integer d){
		data=d;
	}
	public boolean equals(Object o) {
		return true;
	}
	/*public int hashCode() {
		return 1;
	}*/
//}


public class TaskOnStream {
	public static void main(String[] args) {
		int a=10;
		String name="null";
		try {
			a=name.length();
			a++;
		}catch(NullPointerException e) {
			++a;
			return;
		}
		catch(RuntimeException e) {
			a--;
		}
		finally {
			System.out.println(a);
		}
}
}