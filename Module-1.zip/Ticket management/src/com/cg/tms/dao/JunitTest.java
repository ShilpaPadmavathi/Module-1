package com.cg.tms.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

import junit.framework.Assert;

class JunitTest {
	private static Map<String,TicketBean> ticketLog1=new HashMap<String,TicketBean >();
	TicketCategory tc=new TicketCategory("t1", "Software");
	TicketBean tb=new TicketBean("1000", tc, "abc", "low", "new");
	@Test
	public  void raiseNewTicket() {
		// TODO Auto-generated method stub
		
		ticketLog1.put(tb.getTicketNo(), tb);
		String s=tb.getTicketNo();
		int expected=1000;
		int i=Integer.parseInt(s);
		Assert.assertEquals(expected, i);
	}

}
