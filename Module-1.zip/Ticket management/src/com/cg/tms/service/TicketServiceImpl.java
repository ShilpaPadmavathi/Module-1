package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService  {
TicketDAO td=new TicketDAOImpl();
	@Override
	public int raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		int i=td.raiseNewTicket(ticketBean);
		return i;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		List<TicketCategory> l1=td.listTicketCategory();
		return l1;
	}
}
