package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	static TicketService ts=new TicketServiceImpl();
public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	while(true) {
		int ch;
		boolean x=true;
		
		System.out.println("  1.Raise a ticket\n  2.Exit from System\n ");
		ch=sc.nextInt();
		
		switch(ch) {
		case 1: List<TicketCategory> l1=ts.listTicketCategory();
		System.out.println("Select category from following list: \n ");
		for (int i = 0; i < l1.size(); i++) {
			System.out.println((i+1)+". "+l1.get(i).getCategoryName());
		}
		System.out.println("enter option :");
		int op=sc.nextInt();

		TicketCategory tc=new TicketCategory(l1.get(op).getTicketCategoryId(), l1.get(op).getCategoryName());
		System.out.println("enter description related to issue :\n(here you need to type the details)");
		String desc=sc.next();
		desc+=sc.nextLine();
		System.out.println("enter Priority(1.low 2.medium 3.high :");
		int p=sc.nextInt();
		String priority="";
		if(p==1) {
			priority="low";
		}
		else if(p==2) {
			priority="medium";
		}
		if(p==3) {
			priority="high";
		}
		int ticketNo=(int)(Math.random()*1000+1000);
		String ticketNo1=Integer.toString(ticketNo);
		String ticketStatus="New";
		TicketBean tb=new TicketBean(ticketNo1, tc, desc, priority, ticketStatus);
		int i=ts.raiseNewTicket(tb);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now(); 
		System.out.println("Ticket Number "+i+ " logged succesfully at "+dtf.format(now));
		break;
		case 2:System.exit(0);
		default : System.out.println("Enter valid option");
		}
		
	}
}
}
