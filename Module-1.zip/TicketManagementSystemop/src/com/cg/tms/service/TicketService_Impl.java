package com.cg.tms.service;



import java.util.List;



import com.cg.tms.dao.*;

import com.cg.tms.dto.*;



public class TicketService_Impl implements TicketService{



 TicketDAO td = new TicketDAO_Impl();

 public boolean raiseNewTicket(TicketBean ticketBean) {

 // TODO Auto-generated method stub



 return td.raiseNewTicket(ticketBean);

 }



 @Override

 public List<TicketCategory> listTicketCategory() {

 // TODO Auto-generated method stub

 return td.listTicketCategory();

 }



}

