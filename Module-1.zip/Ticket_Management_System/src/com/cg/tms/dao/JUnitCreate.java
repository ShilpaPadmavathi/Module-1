package com.cg.tms.dao;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

import junit.framework.Assert;

public class JUnitCreate {
		private static Map<String,TicketBean> ticketing=new HashMap<String,TicketBean >();
		TicketCategory tc=new TicketCategory("t3", "Network");
		TicketBean ticketbean=new TicketBean("1221", tc, "Network", "low", "next");
		@Test
		public  void raiseNewTicket() {
			// TODO Auto-generated method stub
			
			ticketing.put(ticketbean.getTicketNo(), ticketbean);
			String s=ticketbean.getTicketNo();
			int expected=1221;
			int i=Integer.parseInt(s);
			Assert.assertEquals(expected, i);
		}
	}