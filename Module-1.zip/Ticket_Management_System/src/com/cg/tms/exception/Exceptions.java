package com.cg.tms.exception;

public class Exceptions extends Exception{
	public Exceptions(String message) {
		super(message);
	}


}
