package com.cg.tms.ui;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	static TicketService ts=new TicketServiceImpl();//Calling object of Service Impl indirectly 
public static void main(String[] args) {
	System.out.println("Welcome to ITIMD Help Desk");
	Scanner scanner= new Scanner(System.in);//scanner for inputs
	while(true) {
		int choice;
		System.out.println("1.Raise a ticket\n2.Exit\nEnter Your Option:");//Displaying the options for User Selection
		choice=scanner.nextInt();
		switch(choice) {
		case 1: 
			List<TicketCategory> list=ts.listTicketCategory();
		System.out.println("Select category from following list:\n ");
		int i=0;
		while(i<list.size()) {
			System.out.println((i+1)+". "+list.get(i).getCategoryName());
			i++;
		}
		System.out.println("enter option :");
		int operate=scanner.nextInt();
		TicketCategory tc=new TicketCategory(list.get(operate-1).getTicketCategoryId(), list.get(operate-1).getCategoryName());
		//Passing the Data to the Ticket Category
		System.out.println("Enter description related to issue: (here you need to type the details)");
		String desc=scanner.next();
		if(desc.length()>4) {
		desc+=scanner.nextLine();
		}
		else {
			System.out.println("Enter the description of length greater than 4 without gaps");
			System.exit(0);
		}
		System.out.println("Enter Priority(1.low 2.medium 3.high :");//Entering the Priority
		int priority=scanner.nextInt();
		String prior="";
		if(priority==1) {//Giving the Priorities from 1 To 3
			prior="low";
		}
		else if(priority==2) {
			prior="medium";
		}
		if(priority==3) {
			prior="high";
		}
		int ticketNo=(int)(Math.random()*1000+1000);//Generating the ticket Number using math.random method
		String ticket=Integer.toString(ticketNo);
		String status="New";
		TicketBean tb=new TicketBean(ticket, tc, desc, prior, status);//Passing the Data To the Bean
		int raise=ts.raiseNewTicket(tb);
		DateTimeFormatter datetimeformatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"); //Format for Displaying the Dates
		   LocalDateTime time = LocalDateTime.now(); 
		System.out.println("Ticket Number "+raise+ " logged succesfully at "+datetimeformatter.format(time));//Displaying the Data received in a particular format
		break;
		case 2:
			System.exit(0);
			break;
		default :
			System.out.println("Enter Correct option");
			break;
		}
	}
	
}
}
